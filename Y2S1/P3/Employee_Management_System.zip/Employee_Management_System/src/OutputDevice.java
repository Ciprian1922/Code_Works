public class OutputDevice {
    public static void write(String message){
        System.out.println(message);
    }
}
