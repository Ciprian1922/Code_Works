public interface Upgradable {
    boolean isUpgradable();
    void upgrade();
}
