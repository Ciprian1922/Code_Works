public enum Role {
    Intern, Junior, Associate, Intermediate, Senior, Lead, Team_Lead, Director, Ceo
}
