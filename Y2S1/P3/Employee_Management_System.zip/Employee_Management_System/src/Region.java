public enum Region {
    Romania, Germany, Italy, Spain, Sweden
}
