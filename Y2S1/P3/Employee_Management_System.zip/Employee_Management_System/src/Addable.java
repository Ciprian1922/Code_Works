public interface Addable {
    boolean validateEmployeeInput(int id, String name, int age, Role function, boolean isMarried, Region region);
}
