run in cmd:

python simple_server.py


open in browser

http://localhost:8000/library.xml