import java.util.ArrayList;
import java.util.List;
public class Bank {
	private String name;
	private List<Client> clients;
	private DailyOperationsReport operationsReport;
	private DailyClientChangesReport clientChangesReport;
	private Logger logger;
	private Mediator mediator;

	public Bank(String name) {
		this.name = name;
		this.clients = new ArrayList<>();
		this.operationsReport = new DailyOperationsReport();
		this.clientChangesReport = new DailyClientChangesReport();
		this.logger = Logger.getInstance();
	}

	public void setMediator(Mediator mediator) {
		this.mediator = mediator;  // Allow setting the mediator after Bank initialization
	}

	public void addClient(Client client) {
		clients.add(client);
		clientChangesReport.addClientChange("Added client: " + client.getName());
		logger.log("Added client: " + client.getName());
		operationsReport.addOperation("Added client: " + client.getName());
	}

	public void removeClient(Client client) {
		clients.remove(client);
		clientChangesReport.addClientChange("Removed client: " + client.getName());
		logger.log("Removed client: " + client.getName());
		operationsReport.addOperation("Removed client: " + client.getName());
	}

	public void performOperation(Command command) {
		try {
			command.execute();
			operationsReport.addOperation("Executed command: " + command.toString());
			logger.log("Performed operation: " + command.toString());
		} catch (Exception e) {
			logger.log("Error performing operation: " + e.getMessage());
		}
	}

	public void generateReports() {
		operationsReport.generateReport();
		clientChangesReport.generateReport();
	}
	public List<Client> getClients() {
		return clients;
	}
	@Override
	public String toString() {
		return "Bank [name=" + name + ", clients=" + clients + "]";
	}
}

