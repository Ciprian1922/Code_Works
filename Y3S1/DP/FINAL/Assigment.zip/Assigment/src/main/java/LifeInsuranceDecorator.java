public class LifeInsuranceDecorator extends AccountDecorator {

    public LifeInsuranceDecorator(Client client) {
        super(client);
    }

    // Method to apply life insurance bonus (without re-depositing the base amount)
    public void deposeWithBonus(String accountNumber, double amount) throws InvalidAmountException {
        Account account = wrappedClient.getAccount(accountNumber); // Retrieve the account
        if (account != null) {
            double bonus = amount * 0.1; // 10% life insurance bonus
            account.depose(bonus); // Apply bonus to the account
            account.getTransactions().add("Life Insurance bonus applied: " + bonus); // Log bonus
        } else {
            throw new IllegalArgumentException("Account not found: " + accountNumber);
        }
    }

    @Override
    public String toString() {
        return super.toString() + " (LifeInsuranceDecorator applied)";
    }
}

















