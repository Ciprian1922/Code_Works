public class TransferCommand implements Command {
    private Account source;
    private Account target;
    private double amount;

    public TransferCommand(Account source, Account target, double amount) {
        this.source = source;
        this.target = target;
        this.amount = amount;
    }

    @Override
    public void execute() {
        try {
            source.retrieve(amount);
            target.depose(amount);
        } catch (InsufficientFundsException | InvalidAmountException e) {
            System.err.println("Transfer failed: " + e.getMessage());
        }
    }
}