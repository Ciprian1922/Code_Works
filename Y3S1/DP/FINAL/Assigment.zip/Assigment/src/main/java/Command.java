// Command interface
public interface Command {
    void execute();
}
