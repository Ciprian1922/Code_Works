package operations;

// operations.Command interface
public interface Command {
    void execute();
}
