package singleton;

import java.util.logging.Logger;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;
import java.io.IOException;

/**
 * Logging for the entire application.
 * Logs information to a file called bank_operations.log
 */
public class AppLogger {
    private static Logger logger = Logger.getLogger("BankLogger");

    static {
        try {
            FileHandler fileHandler = new FileHandler("bank_operations.log", true);
            fileHandler.setFormatter(new SimpleFormatter());
            logger.addHandler(fileHandler);
            logger.setUseParentHandlers(false);
        } catch (IOException e) {
            System.err.println("Failed to initialize logger: " + e.getMessage()); // EXCEPTION HANDLING IN SINGLETON LOGGER IMPLEMENTED
            /**
             Robust exception handling is added to the AppLogger class to gracefully handle issues during logger initialization
             or while saving reports. Errors are either logged to the console or to the logger file, ensuring smooth program execution without crashes.
             */
        }
    }

    public static void logInfo(String message) {
        logger.info(message); // LOGGING FUNCTIONALITY IMPLEMENTED
    }

    public static void logWarning(String message) {
        logger.warning(message); // LOGGING FUNCTIONALITY IMPLEMENTED
    }
}
