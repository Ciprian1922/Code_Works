package operations;

import accounts.Account;

public interface Transfer {
	public void transfer(Account c, double s);  //TRANSFER FUNCTIONALITY
}
